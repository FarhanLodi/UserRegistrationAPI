﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using UserRegistrationAPI.Data;
using UserRegistrationAPI.Models;

namespace UserRegistrationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
   // [Authorize]
    public class UserController : ControllerBase
    {
        private readonly DataContext _dbContext;
        public UserController(DataContext dbcontext)
        {
            _dbContext = dbcontext;
        }
       [HttpGet]
        public IActionResult GetUsers()
        {
            // Get the authenticated user's claims
            var claimsIdentity = User.Identity as ClaimsIdentity;
            var isAdmin = claimsIdentity?.FindFirst(ClaimTypes.Role)?.Value == "Admin";

            List<UserRegistration> users;
            if (isAdmin)
            {
                users = _dbContext.UserRegistrations.ToList();
            }
            else
            {
                users = _dbContext.UserRegistrations.Select(u => new UserRegistration
                {
                    Id = u.Id,
                    Name = u.Name,
                    Email = u.Email
                }).ToList();
            }

            return Ok(users);
        }
        [HttpGet("{ids}")]
        public IActionResult GetUsersByIds(string ids)
        {
            var idList = ids.Split(',');

            var users = _dbContext.UserRegistrations
                .Where(u => idList.Contains(u.Id.ToString()))
                .Select(u => new UserRegistration
                {
                    Id = u.Id,
                    Name = u.Name,
                    Email = u.Email,
                    Password = u.Password,
                    Phone = u.Phone,
                    City = u.City,
                })
                .ToList();

            return Ok(users);
        }
    }
}
