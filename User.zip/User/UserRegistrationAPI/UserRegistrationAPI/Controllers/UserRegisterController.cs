﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using UserRegistrationAPI.Data;
using UserRegistrationAPI.Models;

namespace UserRegistrationAPI.Controllers
{
    
    
    [ApiController]
    public class UserRegisterController : ControllerBase
    {
        private readonly DataContext _dbContext;
        private readonly IConfiguration _configuration;
        public UserRegisterController(DataContext dbcontext,IConfiguration configuration)
        {
            _dbContext = dbcontext;
            _configuration = configuration;
        }
        [HttpPost]
        [Route("api/UserRegiste/Register")]
        public async Task<IActionResult> Register(UserRegistration user)
        {
            // Validate input
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Check if the username is already taken
            if (_dbContext.UserRegistrations.Any(u => u.Email == user.Email))
                return Conflict("User is already exist!!.");

            _dbContext.UserRegistrations.Add(user);
            await _dbContext.SaveChangesAsync();

            return Ok("User registered successfully");
        }
        [HttpPost]
        [Route("api/UserRegiste/Login")]
        public IActionResult Login(User user)
        {
            // Validate input
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var existingUser = _dbContext.UserRegistrations.FirstOrDefault(u => u.Email == user.Email && u.Password == user.Password);

            if (existingUser == null)
                return Unauthorized();

            var token = GenerateJwtToken(existingUser,"123");

            return Ok(token);
        }
        public static string GenerateJwtToken(UserRegistration user, string secretKey)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = GenerateKey(secretKey);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                    new Claim(ClaimTypes.Name, user.Name),
                   
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        private static byte[] GenerateKey(string secretKey)
        {
            const int keySize = 128;
            using var generator = new RNGCryptoServiceProvider();
            var key = new byte[keySize / 8];
            generator.GetBytes(key);
            return key;
        }
    }
}

